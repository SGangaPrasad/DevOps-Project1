/*
 * Logger.java 2014/03/29
 *
 * Copyright (C) 2014 Florin.
 *
 */
package com.bionic_university.carrental.util;

import org.apache.log4j.Logger;

/**
 * This class contains the logger
 *
 * @author Florin
 */
public class Lgr {

    public static final Logger LOGGER = Logger.getLogger(Lgr.class);

}
